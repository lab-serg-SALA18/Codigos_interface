# Painel de Controle do Laboratório NV

Interface única (pygame) para rodar ODMR, Rabi, T1, Hahn Echo, Ramsey, CPMG
(2/4/8) e ESEEM sem precisar abrir dois terminais, ativar dois ambientes
virtuais e editar `ParametrosSequencias.py` na mão toda vez.

## Arquivos

| Arquivo | O que é | Ambiente |
|---|---|---|
| `interface_laboratorio.py` | **A tela principal — é este que você roda.** | Python 3.6 |
| `configuracoes_lab.py` | Caminhos, credenciais, presets de cada experimento. | 3.6 e 3.11 |
| `analise_automatica.py` | Detecção de ressonância (ODMR) e ajustes de T1/T2/T2*/Rabi/ESEEM. | 3.6 |
| `experimento_sequencia.py` | Substitui o `InicializadorSequencias.py` (genérico p/ qualquer sequência). | 3.6 |
| `odmr_controller.py` | Substitui o `odmr.py` (classe `ODMRController`). | 3.6 |
| `servidor_manager.py` | Sobe/derruba o `NVserver.py` e escreve o `ParametrosSequencias.py`. | 3.6 |
| `NVserver.py` | Igual ao original, só sem o `clear_terminal()` a cada pulso. | 3.11 |
| `GeradorSequencias.py`, `pulsed_backend.py`, `qiskit_NV_Backend.py`, `custom_gates.py` | **Sem nenhuma mudança de lógica** — copiados como estavam. | 3.11 |

`ParametrosSequencias.py` **não precisa ser copiado** — a interface escreve
esse arquivo sozinha, do zero, antes de cada medida pulsada.

Dois arquivos que vocês tinham não entraram no pacote:
- **`ativador_camera.txt`**: virou código de verdade, dentro de
  `odmr_controller.py` (`ativar_laser_camera_continuo`). Não precisa mais
  abrir o software da SpinCore manualmente antes do ODMR.
- **`qiskitserver.txt`**: parece ser uma versão antiga/alternativa do
  servidor Qiskit (importa de `circuit_test`, não de `GeradorSequencias`).
  O `NVserver.py` já tem seu próprio `qiskit_server()` embutido, que é o
  que está de fato em uso hoje — por isso deixei esse arquivo de fora. Se
  ele ainda for usado para alguma coisa, me avisa que eu encaixo.

## 1. Instalação

**No ambiente Python 3.6** (o mesmo de hoje, com PyCapture2 e spinapi):
```
pip install pygame scipy
```
(pandas, numpy, matplotlib, h5py, pyvisa, requests, tqdm vocês já têm, pois
o `odmr.py`/`InicializadorSequencias.py` originais já usavam tudo isso.)

Se o `pip install pygame` reclamar de versão no Python 3.6, tente
`pip install "pygame<2.2"`.

**No ambiente Python 3.11**: nada novo — continua exatamente o que já
está instalado hoje (Qiskit, spinapi).

## 2. Colocar os arquivos no lugar

Copie todos os arquivos `.py` deste pacote para dentro de
`C:\Users\lab\Desktop\NV\Joao_pedro\Rabi` (a mesma pasta onde já estão
`NVserver.py`, `GeradorSequencias.py` etc. hoje — pode sobrescrever).

## 3. Configurar `configuracoes_lab.py`

Abra o arquivo e confira/ajuste **uma vez só**:

```python
PYTHON_311_EXE = r"C:\Users\lab\Desktop\NV\python3_11\Scripts\python.exe"
PASTA_PROJETO  = r"C:\Users\lab\Desktop\NV\Joao_pedro\Rabi"
PASTA_DADOS_BASE = r"C:\Users\lab\Desktop\NV\Joao_pedro"
MW_RESOURCE_NAME = "GPIB0::27::INSTR"
```

Ajustei `PYTHON_311_EXE` para apontar direto para o `python.exe` de dentro
do venv 3.11 — é o mesmo ambiente que hoje você ativa com
`python3_11\Scripts\Activate.ps1`, só que chamado direto, sem precisar
ativar nada na mão.

## 4. Rodar

Com o ambiente Python 3.6 ativado:
```
python interface_laboratorio.py
```

Isso abre a janela. Fluxo:
1. Clique no experimento na barra lateral (ODMR, Rabi, T1, HAN, RAM,
   CPMG-2/4/8, ESEEM).
2. Os campos já vêm preenchidos (primeira vez: com os valores padrão de
   `configuracoes_lab.py`; depois disso: com os últimos valores que você
   usou naquele experimento — fica salvo sozinho em
   `ultima_configuracao.json`).
3. Edite o que quiser e clique em **Executar**.
   - ODMR: mede direto.
   - Os outros: a interface escreve o `ParametrosSequencias.py`, sobe o
     `NVserver.py` no Python 3.11 sozinha (o log dele aparece na caixa de
     status), espera as duas portas responderem, e só então começa a medir.
4. Acompanhe o progresso na barra e no log.
5. No final: o valor ajustado (T1/T2/T2*/frequência de Rabi/frequência do
   ESEEM, ou a ressonância de maior contraste no ODMR) aparece grande no
   painel da direita, com uma prévia do gráfico. **Ver gráfico completo**
   abre o PNG salvo em tamanho real.
6. **Parar** cancela a medida em andamento (espera o passo atual terminar
   e desliga a MW/câmera/servidor com segurança).

Os dados e gráficos continuam sendo salvos em `Joao_pedro\<Experimento>\Dados`
e `Joao_pedro\<Experimento>\Graficos`, do mesmo jeito que já era — só que
agora cada experimento (T1, HAN, RAM...) tem sua própria subpasta, em vez
de tudo cair dentro de "Rabi".

## 5. Coisas para conferir antes de confiar 100% nos resultados

Fiz um trabalho cuidadoso de ler todo o código que vocês mandaram para
manter a física e a comunicação entre os processos exatamente como
estavam — mas não tenho como testar contra a câmera, o SpinCore ou o
gerador de MW de verdade daqui. Antes de rodar uma medida "de valer":

- **Trigger da câmera** (`experimento_sequencia.py`,
  `habilitar_trigger_camera`): configurei `polarity=1` (alto, como pedido),
  `mode=0` e `source=0`, que é o padrão para câmeras Point Grey/FLIR com um
  único pino de trigger. Se a exposição não sincronizar com o pulso, o
  `source` pode precisar mudar (depende de qual GPIO está cabeado à
  SpinCore). Rode um teste curto (poucas médias) e confira se as imagens
  saem com contagem normal antes de rodar uma medida longa.
- **Presets de tempo** (`configuracoes_lab.py`, `EXPERIMENTOS`): usei os
  valores que vocês já usam hoje para ODMR e T1. Para Rabi, Hahn, Ramsey,
  CPMG e ESEEM eu escolhi faixas típicas para NV à temperatura ambiente,
  mas são só um ponto de partida — ajuste na tela conforme o que vocês já
  sabem da amostra (e o valor editado fica salvo para a próxima vez).
- **Ajuste automático** (`analise_automatica.py`): T1/T2/CPMG usam
  exponencial (esticada para T2), Rabi e Ramsey usam cosseno (amortecido
  quando dá certo), ESEEM usa FFT do resíduo. Se o ajuste falhar (sinal
  muito ruidoso, poucos pontos), a interface mostra a mensagem de erro em
  vez de um número errado — não tem fallback "forçado".
- **Imagem por frame**: desliguei o salvamento de um `.png` por frame
  individual por padrão (`SALVAR_IMAGENS_INDIVIDUAIS = False` em
  `configuracoes_lab.py`) porque isso gerava milhares de arquivos por
  medida e deixava tudo mais lento. Os dados somados continuam indo pro
  `.h5f`, como sempre. Se precisar dos frames individuais de volta, é só
  mudar essa flag para `True`.
- Também passei a desligar a potência da MW (-100 dBm) no final de
  qualquer medida pulsada, não só no ODMR — o `InicializadorSequencias.py`
  original não fazia isso e podia deixar a MW ligada na última frequência
  usada.

## 6. Se algo der errado

O log dentro da caixa de status mostra a saída do `NVserver.py` em tempo
real — geralmente já diz o que houve (porta ocupada, caminho errado do
Python 3.11, erro de conexão com a câmera/GPIB). Erros de hardware
continuam aparecendo como no código original (a interface não tenta
"esconder" uma exceção de verdade, só evita que ela derrube a janela).
